export interface Card{
    name: string;
    id: number;
    description: string;
    columnId: number;
}
